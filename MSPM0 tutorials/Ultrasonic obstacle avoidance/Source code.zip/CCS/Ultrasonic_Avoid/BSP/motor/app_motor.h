#ifndef __APP_MOTOR_H
#define __APP_MOTOR_H

#include "ALLHeader.h"


void Motion_Set_Pwm(int16_t Motor_1, int16_t Motor_2, int16_t Motor_3, int16_t Motor_4);

#endif
