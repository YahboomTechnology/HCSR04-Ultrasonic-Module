/*
 * bsp_motor.h
 *
 *  Created on: Sep 26, 2023
 *      Author: YB-101
 */

#ifndef BSP_MOTOR_H_
#define BSP_MOTOR_H_

#include "ALLHeader.h"

#define PWM_M1_A(value) DL_TimerG_setCaptureCompareValue(PWM_0_INST,value,GPIO_PWM_0_C0_IDX);
#define PWM_M1_B(value) DL_TimerG_setCaptureCompareValue(PWM_0_INST,value,GPIO_PWM_0_C1_IDX);
#define PWM_M2_A(value) DL_TimerG_setCaptureCompareValue(PWM_0_INST,value,GPIO_PWM_0_C2_IDX);
#define PWM_M2_B(value) DL_TimerG_setCaptureCompareValue(PWM_0_INST,value,GPIO_PWM_0_C3_IDX);

#define PWM_M3_A(value) DL_TimerG_setCaptureCompareValue(PWM_1_INST,value,GPIO_PWM_1_C0_IDX);
#define PWM_M3_B(value) DL_TimerG_setCaptureCompareValue(PWM_1_INST,value,GPIO_PWM_1_C1_IDX);
#define PWM_M4_A(value) DL_TimerG_setCaptureCompareValue(PWM_2_INST,value,GPIO_PWM_2_C0_IDX);
#define PWM_M4_B(value) DL_TimerG_setCaptureCompareValue(PWM_2_INST,value,GPIO_PWM_2_C1_IDX);

#define MOTOR_IGNORE_PULSE (100)
#define MOTOR_MAX_PULSE (1000)

// MOTOR: M1 M2 M3 M4
// MOTOR: L1 L2 R1 R2
typedef enum
{
	MOTOR_ID_M1 = 0,
	MOTOR_ID_M2,
	MOTOR_ID_M3,
	MOTOR_ID_M4,
	MAX_MOTOR
} Motor_ID;

void Motor_Set_Pwm(uint8_t id, int16_t speed);
void Motor_Stop(uint8_t brake);

#endif /* BSP_MOTOR_H_ */
