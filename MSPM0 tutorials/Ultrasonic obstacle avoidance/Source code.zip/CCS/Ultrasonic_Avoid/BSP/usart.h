#ifndef	__USART_H__
#define __USART_H__

#include "ALLHeader.h"

void USART_Init(void);

void uart0_send_char(char ch);
void uart0_send_string(char* str);

#endif
