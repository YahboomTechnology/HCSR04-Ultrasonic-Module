#include "stm32f10x.h"
#include "SysTick.h"
#include "UART.h"
#include "HC_SR04.h"


int main(void)
{
    
    SysTick_Init();//滴答定时器初始化
    UART1_Init();//UART1初始化
    TIM2_Count_Init();//定时器2功能初始化
    Trig_Echo_Init();//HC_SR04 TRIG ECHO引脚初始化 PA1 PA2
	
	printf("Start measuring distances!\n");
	
    while(1)
    {
        HC_SR04_Data();//Trig发送高电平触发测距 获取Echo高电平时间并转换成距离
    }
}
