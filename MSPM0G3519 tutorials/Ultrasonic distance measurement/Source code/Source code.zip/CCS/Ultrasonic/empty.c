#include "AllHeader.h"


int main(void)
{
    //�������ʼ��  Development board initialization
    USART_Init();
    Ultrasonic_Init();
    printf("Init Ultrasonic\r\n");
    while(1)
    {
        volatile uint32_t Value = (int)Hcsr04GetLength();
        printf("Distance = %dCM\r\n", Value);
        delay_ms(5);
    }
}

