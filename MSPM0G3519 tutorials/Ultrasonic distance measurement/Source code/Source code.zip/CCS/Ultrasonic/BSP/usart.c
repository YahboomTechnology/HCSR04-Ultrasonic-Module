#include "usart.h"

#define RE_0_BUFF_LEN_MAX	128

volatile uint8_t  recv0_buff[RE_0_BUFF_LEN_MAX] = {0};
volatile uint16_t recv0_length = 0;
volatile uint8_t  recv0_flag = 0;

void USART_Init(void)
{
	// SYSCFG初始化
	// SYSCFG initialization
	SYSCFG_DL_init();
	//清除串口中断标志
	//Clear the serial port interrupt flag
	NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);
	//使能串口中断
	//Enable serial port interrupt
	NVIC_EnableIRQ(UART_0_INST_INT_IRQN);
}

//串口发送单个字符
//Send a single character through the serial port
void uart0_send_char(char ch)
{
	//当串口0忙的时候等待，不忙的时候再发送传进来的字符
	//Wait when serial port 0 is busy, and send the incoming characters when it is not busy
	while( DL_UART_isBusy(UART_0_INST) == true );
	//发送单个字符
	//Send a single character
	DL_UART_Main_transmitData(UART_0_INST, ch);

}
//串口发送字符串	Send string via serial port
void uart0_send_string(char* str)
{
	//当前字符串地址不在结尾 并且 字符串首地址不为空
	//The current string address is not at the end and the string's first address is not empty
	while(*str!=0&&str!=0)
	{
		//发送字符串首地址中的字符，并且在发送完成之后首地址自增
		//Send the characters in the first address of the string, and the first address will increment automatically after the sending is completed.
		uart0_send_char(*str++);
	}
}


#if !defined(__MICROLIB)
//不使用微库的话就需要添加下面的函数
//If you don't use the micro library, you need to add the following function
#if (__ARMCLIB_VERSION <= 6000000)
//如果编译器是AC5  就定义下面这个结构体
//If the compiler is AC5, define the following structure
struct __FILE
{
	int handle;
};
#endif

FILE __stdout;

//定义_sys_exit()以避免使用半主机模式
//Define _sys_exit() to avoid using semihosting mode
void _sys_exit(int x)
{
	x = x;
}
#endif
int fputc(int ch, FILE* stream)//重定向函数
{
      /*
    DL_UART_Main_transmitData();
    这个函数不是阻塞函数。
    当执行到这个函数的时候，它会把这个字符c发送给串口UART进行发送，把这个数据写入给寄存器之后就会返回，继续执行下面的程序
    但是此时还没有发送完成，只是发出了发送的请求，但是整个发送还没有完成
    DL_UART_Main_transmitDataBlocking();
    这个函数是一个阻塞函数。
    它会把这个字符发给那边串口的寄存器，等待串口发送完成后，它再执行后续的程序
    DL_UART_Main_transmitDataBlocking();//内容发送完了才执行下一步的程序
    DL_UART_Main_transmitDataBlocking();
    这两句话这么写是没有问题的
    DL_UART_Main_transmitData();//只是发送了一个发送请求，但是内容还未发送完
    DL_UART_Main_transmitData();
    但是要这么写就有问题了
    要下面这样写
    */
    uart0_send_char(ch);
  
    return ch;
}
/*如果只使用上面的fputc这个函数，那么就只能打印helloword这个字符串，不能打印后面的参数
所以我们要使用后面的fputs这个才能打印后面的参数
fputs和puts是同时定义的，如果只使用其中一个的话有时候会提示一个重定向的报错
*/
int fputs(const char* restrict s, FILE* restrict stream)
{
    uint16_t i,len;
    len=strlen(s);
    for (i=0; i<len; i++)
    {
        uart0_send_char(s[i]);
    }  
    return len;
}
 
int puts(const char *_ptr)
{
    int count =fputs(_ptr, stdout);
    count +=fputs("\n", stdout);
    return count;
}





void UART_0_INST_IRQHandler(void)
{
	uint8_t receivedData = 0;
	
	//如果产生了串口中断
	//If a serial port interrupt occurs
	switch( DL_UART_getPendingInterrupt(UART_0_INST) )
	{
		case DL_UART_IIDX_RX://如果是接收中断	If it is a receive interrupt
			
			// 接收发送过来的数据保存	Receive and save the data sent
			receivedData = DL_UART_Main_receiveData(UART_0_INST);

			// 检查缓冲区是否已满	Check if the buffer is full
			if (recv0_length < RE_0_BUFF_LEN_MAX - 1)
			{
				recv0_buff[recv0_length++] = receivedData;

				// 将保存的数据再发送出去，不想回传可以注释掉
				//Send the saved data again. If you don’t want to send it back, you can comment it out.
				uart0_send_char(receivedData);
			}
			else
			{
				recv0_length = 0;
			}

			// 标记接收标志	Mark receiving flag
			recv0_flag = 1;
		
			break;
		
		default://其他的串口中断	Other serial port interrupts
			break;
	}
}
