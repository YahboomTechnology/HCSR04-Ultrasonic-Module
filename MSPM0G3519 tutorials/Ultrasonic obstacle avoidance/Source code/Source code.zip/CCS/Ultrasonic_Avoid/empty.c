#include "AllHeader.h"


int main(void)
{
    //开发板初始化  Development board initialization
    USART_Init();
    Ultrasonic_Init();
    
    while(1)
    {
        uint32_t Value = (int)Hcsr04GetLength();
//		printf((const char *)"Distance = %dCM\r\n", Value);

		if(Value>30)//前方30CM以内无障碍物时	When there is no obstacle within 30CM in front
		{
			Motion_Set_Pwm(100,100,100,100);//前进	Forward
			delay_ms(100);
		}
		else//当检测到前方障碍物小于30CM	When the obstacle ahead is detected to be less than 30CM
		{
			Motion_Set_Pwm(-100,-100,-100,-100);//先后退，后右转	Back up first, then turn right
			delay_ms(500);
			Motion_Set_Pwm(700,-300,700,-300);
			delay_ms(500);
		}
    }
}
