################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/motor/app_motor.c \
../BSP/motor/bsp_motor.c 

C_DEPS += \
./BSP/motor/app_motor.d \
./BSP/motor/bsp_motor.d 

OBJS += \
./BSP/motor/app_motor.o \
./BSP/motor/bsp_motor.o 

OBJS__QUOTED += \
"BSP\motor\app_motor.o" \
"BSP\motor\bsp_motor.o" 

C_DEPS__QUOTED += \
"BSP\motor\app_motor.d" \
"BSP\motor\bsp_motor.d" 

C_SRCS__QUOTED += \
"../BSP/motor/app_motor.c" \
"../BSP/motor/bsp_motor.c" 


